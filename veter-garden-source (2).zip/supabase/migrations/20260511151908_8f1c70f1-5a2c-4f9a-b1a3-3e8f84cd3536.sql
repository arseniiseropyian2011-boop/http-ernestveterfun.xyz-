
-- fix search_path on set_updated_at
create or replace function public.set_updated_at()
returns trigger
language plpgsql
security invoker
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- revoke direct execute on security definer trigger functions
revoke execute on function public.handle_new_user() from public, anon, authenticated;
revoke execute on function public.set_updated_at() from public, anon, authenticated;

-- restrict avatars listing: only allow reading own folder via list, but keep
-- public read by file path. Replace the broad SELECT policy with one scoped
-- by folder or signed URL usage. Since we want public avatar URLs to work,
-- keep public select but do not allow listing (no list operation without auth).
drop policy if exists "avatars are publicly accessible" on storage.objects;

create policy "avatars public read"
  on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'avatars');
