
-- POSTS: add media columns + relax content NOT NULL (allow media-only posts)
alter table public.posts
  alter column content drop not null,
  add column media_url text,
  add column media_type text check (media_type in ('image','video','audio'));

alter table public.posts drop constraint if exists posts_content_check;
alter table public.posts add constraint posts_content_or_media_check
  check (
    (content is not null and char_length(content) between 1 and 2000)
    or media_url is not null
  );

-- FRIENDSHIPS
create type public.friend_status as enum ('pending','accepted');

create table public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id) on delete cascade,
  addressee_id uuid not null references public.profiles(id) on delete cascade,
  status public.friend_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (requester_id, addressee_id),
  check (requester_id <> addressee_id)
);

create index friendships_addressee_idx on public.friendships(addressee_id, status);
create index friendships_requester_idx on public.friendships(requester_id, status);

alter table public.friendships enable row level security;

create policy "friendships visible to participants"
  on public.friendships for select
  using (auth.uid() = requester_id or auth.uid() = addressee_id);

create policy "users can request friendship"
  on public.friendships for insert
  with check (auth.uid() = requester_id);

create policy "addressee can update status"
  on public.friendships for update
  using (auth.uid() = addressee_id or auth.uid() = requester_id);

create policy "participants can delete"
  on public.friendships for delete
  using (auth.uid() = requester_id or auth.uid() = addressee_id);

create trigger friendships_set_updated_at
before update on public.friendships
for each row execute function public.set_updated_at();

-- DIRECT MESSAGES
create table public.direct_messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  content text,
  media_url text,
  media_type text check (media_type in ('image','video','audio')),
  created_at timestamptz not null default now(),
  read_at timestamptz,
  check (
    (content is not null and char_length(content) between 1 and 2000)
    or media_url is not null
  )
);

create index dm_pair_idx on public.direct_messages(sender_id, recipient_id, created_at);
create index dm_recipient_idx on public.direct_messages(recipient_id, created_at desc);

alter table public.direct_messages enable row level security;

create policy "dm visible to participants"
  on public.direct_messages for select
  using (auth.uid() = sender_id or auth.uid() = recipient_id);

create policy "users can send dm"
  on public.direct_messages for insert
  with check (auth.uid() = sender_id);

create policy "recipient can mark read"
  on public.direct_messages for update
  using (auth.uid() = recipient_id);

create policy "sender can delete own dm"
  on public.direct_messages for delete
  using (auth.uid() = sender_id);

-- realtime
alter publication supabase_realtime add table public.direct_messages;
alter publication supabase_realtime add table public.friendships;

-- STORAGE buckets for post & dm media
insert into storage.buckets (id, name, public) values ('post-media','post-media',true)
on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('dm-media','dm-media',true)
on conflict (id) do nothing;

create policy "post-media public read"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'post-media');
create policy "post-media owner write"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'post-media' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "post-media owner delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'post-media' and auth.uid()::text = (storage.foldername(name))[1]);

create policy "dm-media public read"
  on storage.objects for select to anon, authenticated
  using (bucket_id = 'dm-media');
create policy "dm-media owner write"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'dm-media' and auth.uid()::text = (storage.foldername(name))[1]);
create policy "dm-media owner delete"
  on storage.objects for delete to authenticated
  using (bucket_id = 'dm-media' and auth.uid()::text = (storage.foldername(name))[1]);
