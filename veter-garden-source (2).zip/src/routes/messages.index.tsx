import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/messages/")({
  component: MessagesIndex,
});

type Conv = {
  otherId: string;
  username: string;
  avatar_url: string | null;
  lastContent: string | null;
  lastMediaType: string | null;
  lastAt: string;
};

function MessagesIndex() {
  const { user, loading } = useAuth();
  const [convs, setConvs] = useState<Conv[]>([]);
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    if (!user) return;
    const load = async () => {
      const { data, error } = await supabase
        .from("direct_messages")
        .select(`
          id, sender_id, recipient_id, content, media_type, created_at,
          sender:profiles!direct_messages_sender_id_fkey(id, username, avatar_url),
          recipient:profiles!direct_messages_recipient_id_fkey(id, username, avatar_url)
        `)
        .or(`sender_id.eq.${user.id},recipient_id.eq.${user.id}`)
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) { setBusy(false); return; }
      const map = new Map<string, Conv>();
      for (const m of (data ?? []) as any[]) {
        const isOut = m.sender_id === user.id;
        const other = isOut ? m.recipient : m.sender;
        if (!other) continue;
        if (map.has(other.id)) continue;
        map.set(other.id, {
          otherId: other.id,
          username: other.username,
          avatar_url: other.avatar_url,
          lastContent: m.content,
          lastMediaType: m.media_type,
          lastAt: m.created_at,
        });
      }
      setConvs(Array.from(map.values()));
      setBusy(false);
    };
    load();

    const channel = supabase
      .channel("dm-list")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "direct_messages" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user]);

  if (!loading && !user) return <Navigate to="/auth" />;
  if (!user) return null;

  return (
    <div className="space-y-3">
      <h1 className="text-xl font-bold">Сообщения</h1>
      {busy && <p className="text-sm text-muted-foreground">Загрузка…</p>}
      {!busy && convs.length === 0 && (
        <p className="text-sm text-muted-foreground">
          Пока нет диалогов. Зайди на чей-то <Link to="/friends" className="underline">профиль</Link> и напиши первое сообщение.
        </p>
      )}
      {convs.map((c) => (
        <Link key={c.otherId} to="/messages/$id" params={{ id: c.otherId }}>
          <Card className="hover:bg-accent">
            <CardContent className="flex items-center gap-3 p-3">
              <Avatar><AvatarImage src={c.avatar_url ?? undefined} /><AvatarFallback>{c.username[0]?.toUpperCase()}</AvatarFallback></Avatar>
              <div className="flex-1 overflow-hidden">
                <div className="font-medium">{c.username}</div>
                <div className="truncate text-xs text-muted-foreground">
                  {c.lastContent ?? (c.lastMediaType === "image" ? "📷 Фото" : c.lastMediaType === "video" ? "🎥 Видео" : "🎙 Голосовое")}
                </div>
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  );
}
