import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { PostCard, type PostWithAuthor } from "@/components/post-card";
import { FriendButton } from "@/components/friend-button";
import { VerifiedBadge } from "@/components/verified-badge";
import { toast } from "sonner";

export const Route = createFileRoute("/profile/$id")({
  component: ProfilePage,
});

type Profile = {
  id: string;
  username: string;
  bio: string | null;
  avatar_url: string | null;
  is_verified: boolean;
};

function ProfilePage() {
  const { id } = Route.useParams();
  const { user, refreshProfile } = useAuth();
  const qc = useQueryClient();
  const isOwn = user?.id === id;
  const [editing, setEditing] = useState(false);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, bio, avatar_url, is_verified")
        .eq("id", id)
        .maybeSingle();
      if (error) throw error;
      return data as Profile | null;
    },
  });

  const { data: posts } = useQuery({
    queryKey: ["posts", "user", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("posts")
        .select("id, content, media_url, media_type, created_at, user_id, profiles(username, avatar_url, is_verified)")
        .eq("user_id", id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as PostWithAuthor[];
    },
  });

  const onSave = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const username = String(fd.get("username") ?? "").trim();
    const bio = String(fd.get("bio") ?? "").trim();
    const is_verified = fd.get("is_verified") === "on";
    if (username.length < 3) return toast.error("Имя минимум 3 символа");
    setBusy(true);
    const { error } = await supabase
      .from("profiles")
      .update({ username, bio: bio || null, is_verified })
      .eq("id", id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Сохранено");
    setEditing(false);
    qc.invalidateQueries({ queryKey: ["profile", id] });
    refreshProfile();
  };

  const onAvatar = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 3 * 1024 * 1024) return toast.error("Макс размер 3 МБ");
    setBusy(true);
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${user.id}/avatar-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
    if (upErr) {
      setBusy(false);
      return toast.error(upErr.message);
    }
    const { data: pub } = supabase.storage.from("avatars").getPublicUrl(path);
    const { error } = await supabase.from("profiles").update({ avatar_url: pub.publicUrl }).eq("id", user.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Аватар обновлён");
    qc.invalidateQueries({ queryKey: ["profile", id] });
    refreshProfile();
  };

  if (isLoading) return <p className="text-center text-sm text-muted-foreground">Загрузка…</p>;
  if (!profile) return (
    <div className="text-center">
      <p className="text-muted-foreground">Профиль не найден</p>
      <Link to="/" className="text-primary underline">На главную</Link>
    </div>
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start gap-4">
            <div className="relative">
              <Avatar className="h-20 w-20">
                <AvatarImage src={profile.avatar_url ?? undefined} />
                <AvatarFallback className="text-2xl">{profile.username[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              {isOwn && (
                <>
                  <input ref={fileRef} type="file" accept="image/*" onChange={onAvatar} className="hidden" />
                  <Button
                    size="sm"
                    variant="secondary"
                    className="mt-2 w-full text-xs"
                    onClick={() => fileRef.current?.click()}
                    disabled={busy}
                  >
                    Аватар
                  </Button>
                </>
              )}
            </div>
            <div className="flex-1">
              {editing ? (
                <form onSubmit={onSave} className="space-y-3">
                  <Input name="username" defaultValue={profile.username} required minLength={3} maxLength={30} />
                  <Textarea name="bio" defaultValue={profile.bio ?? ""} placeholder="О себе" rows={3} maxLength={300} />
                  <label className="flex items-center gap-2 text-sm">
                    <input type="checkbox" name="is_verified" defaultChecked={profile.is_verified} />
                    Подтверждённый аккаунт (галочка)
                  </label>
                  <div className="flex gap-2">
                    <Button type="submit" disabled={busy}>Сохранить</Button>
                    <Button type="button" variant="outline" onClick={() => setEditing(false)}>Отмена</Button>
                  </div>
                </form>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <h1 className="text-2xl font-bold inline-flex items-center gap-2">
                      {profile.username}
                      {profile.is_verified && <VerifiedBadge className="h-6 w-6" />}
                    </h1>
                    {isOwn && <Button size="sm" variant="outline" onClick={() => setEditing(true)}>Редактировать</Button>}
                  </div>
                  {profile.bio && <p className="mt-2 whitespace-pre-wrap text-sm text-muted-foreground">{profile.bio}</p>}
                  {!isOwn && <div className="mt-3"><FriendButton targetId={id} /></div>}
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <h2 className="text-lg font-semibold">Посты</h2>
      <div className="space-y-3">
        {posts?.map((p) => <PostCard key={p.id} post={p} />)}
        {posts && posts.length === 0 && (
          <p className="text-sm text-muted-foreground">Постов пока нет</p>
        )}
      </div>
    </div>
  );
}
