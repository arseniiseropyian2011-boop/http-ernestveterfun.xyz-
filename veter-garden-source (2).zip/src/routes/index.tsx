import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { CreatePost } from "@/components/create-post";
import { PostCard, type PostWithAuthor } from "@/components/post-card";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  const { data: posts, isLoading } = useQuery({
    queryKey: ["posts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("posts")
        .select("id, content, media_url, media_type, created_at, user_id, profiles(username, avatar_url, is_verified)")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return (data ?? []) as unknown as PostWithAuthor[];
    },
  });

  return (
    <div className="space-y-4">
      <CreatePost />
      {isLoading && <p className="text-center text-sm text-muted-foreground">Загрузка…</p>}
      {posts?.map((p) => <PostCard key={p.id} post={p} />)}
      {posts && posts.length === 0 && (
        <p className="text-center text-sm text-muted-foreground">
          Пока нет постов. Будь первым!
        </p>
      )}
    </div>
  );
}
