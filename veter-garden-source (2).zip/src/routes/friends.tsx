import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, Search, UserCheck, UserX } from "lucide-react";
import { VerifiedBadge } from "@/components/verified-badge";
import { FriendButton } from "@/components/friend-button";
import { toast } from "sonner";

export const Route = createFileRoute("/friends")({
  component: FriendsPage,
});

type Row = {
  id: string;
  requester_id: string;
  addressee_id: string;
  status: "pending" | "accepted";
  requester: { id: string; username: string; avatar_url: string | null } | null;
  addressee: { id: string; username: string; avatar_url: string | null } | null;
};

function FriendsPage() {
  const { user, loading } = useAuth();

  const { data, refetch } = useQuery({
    queryKey: ["friendships", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("friendships")
        .select(`
          id, requester_id, addressee_id, status,
          requester:profiles!friendships_requester_id_fkey(id, username, avatar_url),
          addressee:profiles!friendships_addressee_id_fkey(id, username, avatar_url)
        `)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data as unknown as Row[];
    },
  });

  if (!loading && !user) return <Navigate to="/auth" />;
  if (!user) return null;

  const accepted = data?.filter((r) => r.status === "accepted") ?? [];
  const incoming = data?.filter((r) => r.status === "pending" && r.addressee_id === user.id) ?? [];
  const outgoing = data?.filter((r) => r.status === "pending" && r.requester_id === user.id) ?? [];

  const otherOf = (r: Row) =>
    r.requester_id === user.id ? r.addressee : r.requester;

  const accept = async (r: Row) => {
    const { error } = await supabase
      .from("friendships").update({ status: "accepted" }).eq("id", r.id);
    if (error) return toast.error(error.message);
    refetch();
  };
  const remove = async (r: Row) => {
    const { error } = await supabase.from("friendships").delete().eq("id", r.id);
    if (error) return toast.error(error.message);
    refetch();
  };

  const Item = ({ r, actions }: { r: Row; actions: React.ReactNode }) => {
    const o = otherOf(r);
    if (!o) return null;
    return (
      <div className="flex items-center gap-3 rounded-md border border-border p-3">
        <Link to="/profile/$id" params={{ id: o.id }}>
          <Avatar><AvatarImage src={o.avatar_url ?? undefined} /><AvatarFallback>{o.username[0]?.toUpperCase()}</AvatarFallback></Avatar>
        </Link>
        <Link to="/profile/$id" params={{ id: o.id }} className="flex-1 font-medium hover:underline">
          {o.username}
        </Link>
        {actions}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <UserSearch currentUserId={user.id} />
      <Card>
        <CardContent className="p-4 space-y-2">
          <h2 className="text-lg font-semibold">Входящие запросы ({incoming.length})</h2>
          {incoming.length === 0 && <p className="text-sm text-muted-foreground">Нет запросов</p>}
          {incoming.map((r) => (
            <Item key={r.id} r={r} actions={
              <div className="flex gap-2">
                <Button size="sm" onClick={() => accept(r)} className="gap-1"><UserCheck className="h-4 w-4" /></Button>
                <Button size="sm" variant="outline" onClick={() => remove(r)} className="gap-1"><UserX className="h-4 w-4" /></Button>
              </div>
            } />
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 space-y-2">
          <h2 className="text-lg font-semibold">Друзья ({accepted.length})</h2>
          {accepted.length === 0 && <p className="text-sm text-muted-foreground">Пока нет друзей</p>}
          {accepted.map((r) => {
            const o = otherOf(r);
            return (
              <Item key={r.id} r={r} actions={
                <div className="flex gap-2">
                  {o && (
                    <Link to="/messages/$id" params={{ id: o.id }}>
                      <Button size="sm" variant="outline" className="gap-1"><MessageCircle className="h-4 w-4" /></Button>
                    </Link>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => remove(r)}>Удалить</Button>
                </div>
              } />
            );
          })}
        </CardContent>
      </Card>

      {outgoing.length > 0 && (
        <Card>
          <CardContent className="p-4 space-y-2">
            <h2 className="text-lg font-semibold">Отправленные ({outgoing.length})</h2>
            {outgoing.map((r) => (
              <Item key={r.id} r={r} actions={
                <Button size="sm" variant="ghost" onClick={() => remove(r)}>Отменить</Button>
              } />
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function UserSearch({ currentUserId }: { currentUserId: string }) {
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");

  useEffect(() => {
    const t = setTimeout(() => setDebounced(q.trim()), 300);
    return () => clearTimeout(t);
  }, [q]);

  const { data, isFetching } = useQuery({
    queryKey: ["user-search", debounced],
    enabled: debounced.length >= 2,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, username, avatar_url, bio, is_verified")
        .ilike("username", `%${debounced}%`)
        .neq("id", currentUserId)
        .limit(20);
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <Card>
      <CardContent className="p-4 space-y-3">
        <h2 className="text-lg font-semibold">Найти людей</h2>
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск по нику…"
            className="pl-9"
          />
        </div>
        {debounced.length > 0 && debounced.length < 2 && (
          <p className="text-sm text-muted-foreground">Введите минимум 2 символа</p>
        )}
        {isFetching && <p className="text-sm text-muted-foreground">Поиск…</p>}
        {debounced.length >= 2 && !isFetching && data && data.length === 0 && (
          <p className="text-sm text-muted-foreground">Никого не найдено</p>
        )}
        <div className="space-y-2">
          {data?.map((p) => (
            <div key={p.id} className="flex items-center gap-3 rounded-md border border-border p-3">
              <Link to="/profile/$id" params={{ id: p.id }}>
                <Avatar>
                  <AvatarImage src={p.avatar_url ?? undefined} />
                  <AvatarFallback>{p.username[0]?.toUpperCase()}</AvatarFallback>
                </Avatar>
              </Link>
              <div className="flex-1 min-w-0">
                <Link
                  to="/profile/$id"
                  params={{ id: p.id }}
                  className="flex items-center gap-1 font-medium hover:underline"
                >
                  <span className="truncate">{p.username}</span>
                  {p.is_verified && <VerifiedBadge />}
                </Link>
                {p.bio && <p className="truncate text-xs text-muted-foreground">{p.bio}</p>}
              </div>
              <FriendButton targetId={p.id} />
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
