import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Страница не найдена</h2>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90">
            На главную
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold">Что-то пошло не так</h1>
        <p className="mt-2 text-sm text-muted-foreground">{error.message}</p>
        <Button className="mt-6" onClick={() => { router.invalidate(); reset(); }}>Повторить</Button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "ErnestVeterFun — соцсеть" },
      { name: "description", content: "Делись постами, общайся и заводи друзей." },
      { property: "og:title", content: "ErnestVeterFun — соцсеть" },
      { name: "twitter:title", content: "ErnestVeterFun — соцсеть" },
      { property: "og:description", content: "Делись постами, общайся и заводи друзей." },
      { name: "twitter:description", content: "Делись постами, общайся и заводи друзей." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/40bb8402-f1d6-40f3-a720-f21cec83cfad/id-preview-4694c952--a784a2e5-8fc5-49e6-af19-10380fed9077.lovable.app-1778513347957.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/40bb8402-f1d6-40f3-a720-f21cec83cfad/id-preview-4694c952--a784a2e5-8fc5-49e6-af19-10380fed9077.lovable.app-1778513347957.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ru">
      <head><HeadContent /></head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function Header() {
  const { user, profile, signOut } = useAuth();
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur">
      <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
        <Link to="/" className="text-xl font-bold tracking-tight">
          Ernest<span className="text-primary">Veter</span>Fun
        </Link>
        <nav className="flex items-center gap-2">
          <Link to="/" className="text-sm font-medium hover:underline">Лента</Link>
          {user ? (
            <>
              <Link to="/friends" className="text-sm font-medium hover:underline">Друзья</Link>
              <Link to="/messages" className="text-sm font-medium hover:underline">Чат</Link>
              <Link
                to="/profile/$id"
                params={{ id: user.id }}
                className="text-sm font-medium hover:underline"
              >
                {profile?.username ?? "Профиль"}
              </Link>
              <Button size="sm" variant="outline" onClick={signOut}>Выйти</Button>
            </>
          ) : (
            <Link to="/auth">
              <Button size="sm">Войти</Button>
            </Link>
          )}
        </nav>
      </div>
    </header>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <div className="min-h-screen bg-background text-foreground">
          <Header />
          <main className="mx-auto max-w-3xl px-4 py-6">
            <Outlet />
          </main>
        </div>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}
