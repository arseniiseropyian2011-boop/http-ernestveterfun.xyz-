import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ArrowLeft, ImagePlus, X } from "lucide-react";
import { toast } from "sonner";
import { detectMediaType, uploadMedia, type MediaType } from "@/lib/media";
import { MediaPreview } from "@/components/media-preview";
import { VoiceRecorder } from "@/components/voice-recorder";

export const Route = createFileRoute("/messages/$id")({
  component: ChatPage,
});

type Msg = {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string | null;
  media_url: string | null;
  media_type: MediaType | null;
  created_at: string;
};

type OtherProfile = { id: string; username: string; avatar_url: string | null };

function ChatPage() {
  const { id: otherId } = Route.useParams();
  const { user, loading } = useAuth();
  const [other, setOther] = useState<OtherProfile | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState<File | Blob | null>(null);
  const [fileExt, setFileExt] = useState("");
  const [mediaType, setMediaType] = useState<MediaType | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("id, username, avatar_url").eq("id", otherId).maybeSingle()
      .then(({ data }) => setOther(data as OtherProfile | null));

    const load = async () => {
      const { data } = await supabase
        .from("direct_messages")
        .select("id, sender_id, recipient_id, content, media_url, media_type, created_at")
        .or(
          `and(sender_id.eq.${user.id},recipient_id.eq.${otherId}),and(sender_id.eq.${otherId},recipient_id.eq.${user.id})`,
        )
        .order("created_at", { ascending: true })
        .limit(500);
      setMsgs((data ?? []) as Msg[]);
    };
    load();

    const channel = supabase
      .channel(`dm-${user.id}-${otherId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "direct_messages" },
        (payload) => {
          const m = payload.new as Msg;
          if (
            (m.sender_id === user.id && m.recipient_id === otherId) ||
            (m.sender_id === otherId && m.recipient_id === user.id)
          ) {
            setMsgs((cur) => cur.some((x) => x.id === m.id) ? cur : [...cur, m]);
          }
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user, otherId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length]);

  if (!loading && !user) return <Navigate to="/auth" />;
  if (!user) return null;

  const setMedia = (f: File | Blob, ext: string, type: MediaType) => {
    setFile(f); setFileExt(ext); setMediaType(type);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(URL.createObjectURL(f));
  };
  const clearMedia = () => {
    setFile(null); setMediaType(null); setFileExt("");
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 25 * 1024 * 1024) return toast.error("Файл больше 25 МБ");
    const t = detectMediaType(f);
    if (!t) return toast.error("Неподдерживаемый формат");
    setMedia(f, f.name.split(".").pop() || "bin", t);
  };

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const content = text.trim();
    if (!content && !file) return;
    setBusy(true);
    try {
      let media_url: string | null = null;
      let media_type: MediaType | null = null;
      if (file && mediaType) {
        const { url } = await uploadMedia("dm-media", user.id, file, fileExt || "webm");
        media_url = url;
        media_type = mediaType;
      }
      const { error } = await supabase.from("direct_messages").insert({
        sender_id: user.id,
        recipient_id: otherId,
        content: content || null,
        media_url,
        media_type,
      });
      if (error) throw error;
      setText("");
      clearMedia();
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-8rem)] flex-col">
      <div className="flex items-center gap-3 border-b border-border pb-3">
        <Link to="/messages"><Button size="icon" variant="ghost"><ArrowLeft className="h-4 w-4" /></Button></Link>
        {other && (
          <Link to="/profile/$id" params={{ id: other.id }} className="flex items-center gap-2 hover:underline">
            <Avatar className="h-9 w-9"><AvatarImage src={other.avatar_url ?? undefined} /><AvatarFallback>{other.username[0]?.toUpperCase()}</AvatarFallback></Avatar>
            <span className="font-medium">{other.username}</span>
          </Link>
        )}
      </div>

      <div className="flex-1 space-y-2 overflow-y-auto py-4">
        {msgs.map((m) => {
          const own = m.sender_id === user.id;
          return (
            <div key={m.id} className={`flex ${own ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${own ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
                {m.content && <p className="whitespace-pre-wrap">{m.content}</p>}
                {m.media_url && m.media_type && (
                  <div className="mt-1"><MediaPreview url={m.media_url} type={m.media_type} /></div>
                )}
                <div className={`mt-1 text-[10px] ${own ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                  {new Date(m.created_at).toLocaleTimeString("ru", { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={send} className="space-y-2 border-t border-border pt-3">
        {previewUrl && mediaType && (
          <div className="relative max-w-xs">
            <MediaPreview url={previewUrl} type={mediaType} />
            <Button type="button" size="icon" variant="secondary" onClick={clearMedia} className="absolute right-1 top-1">
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
        <div className="flex gap-2">
          <input ref={fileRef} type="file" accept="image/*,video/*,audio/*" onChange={onFile} className="hidden" />
          <Button type="button" size="icon" variant="outline" onClick={() => fileRef.current?.click()}>
            <ImagePlus className="h-4 w-4" />
          </Button>
          <VoiceRecorder onRecorded={(blob) => setMedia(blob, "webm", "audio")} disabled={!!file} />
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Сообщение…"
            rows={1}
            className="flex-1 resize-none"
            maxLength={2000}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(e as unknown as React.FormEvent);
              }
            }}
          />
          <Button type="submit" disabled={busy || (!text.trim() && !file)}>OK</Button>
        </div>
      </form>
    </div>
  );
}
