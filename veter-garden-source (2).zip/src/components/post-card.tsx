import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { MessageCircle, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { MediaPreview } from "@/components/media-preview";
import { VerifiedBadge } from "@/components/verified-badge";
import type { MediaType } from "@/lib/media";

export type PostWithAuthor = {
  id: string;
  content: string | null;
  media_url: string | null;
  media_type: MediaType | null;
  created_at: string;
  user_id: string;
  profiles: { username: string; avatar_url: string | null; is_verified?: boolean | null } | null;
};

type Comment = {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  profiles: { username: string; avatar_url: string | null; is_verified?: boolean | null } | null;
};

function timeAgo(iso: string) {
  const d = new Date(iso);
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return "только что";
  if (diff < 3600) return `${Math.floor(diff / 60)} мин назад`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} ч назад`;
  return d.toLocaleDateString("ru");
}

export function PostCard({ post }: { post: PostWithAuthor }) {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [showComments, setShowComments] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: comments = [] } = useQuery({
    queryKey: ["comments", post.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("comments")
        .select("id, content, created_at, user_id, profiles(username, avatar_url, is_verified)")
        .eq("post_id", post.id)
        .order("created_at", { ascending: true });
      if (error) throw error;
      return (data ?? []) as unknown as Comment[];
    },
    enabled: showComments,
  });

  const submitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return toast.error("Войдите, чтобы комментировать");
    const text = commentText.trim();
    if (!text) return;
    setBusy(true);
    const { error } = await supabase
      .from("comments")
      .insert({ post_id: post.id, user_id: user.id, content: text });
    setBusy(false);
    if (error) return toast.error(error.message);
    setCommentText("");
    qc.invalidateQueries({ queryKey: ["comments", post.id] });
  };

  const deletePost = async () => {
    if (!confirm("Удалить пост?")) return;
    const { error } = await supabase.from("posts").delete().eq("id", post.id);
    if (error) return toast.error(error.message);
    qc.invalidateQueries({ queryKey: ["posts"] });
  };

  const author = post.profiles;
  return (
    <Card>
      <CardContent className="space-y-3 p-4">
        <div className="flex items-start gap-3">
          <Link to="/profile/$id" params={{ id: post.user_id }}>
            <Avatar className="h-10 w-10">
              <AvatarImage src={author?.avatar_url ?? undefined} />
              <AvatarFallback>{author?.username?.[0]?.toUpperCase() ?? "?"}</AvatarFallback>
            </Avatar>
          </Link>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <Link
                to="/profile/$id"
                params={{ id: post.user_id }}
                className="font-semibold hover:underline inline-flex items-center gap-1"
              >
                {author?.username ?? "Пользователь"}
                {author?.is_verified && <VerifiedBadge />}
              </Link>
              <span className="text-xs text-muted-foreground">{timeAgo(post.created_at)}</span>
            </div>
            {post.content && <p className="mt-1 whitespace-pre-wrap text-sm">{post.content}</p>}
            {post.media_url && post.media_type && (
              <div className="mt-2"><MediaPreview url={post.media_url} type={post.media_type} /></div>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 border-t border-border pt-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowComments((v) => !v)}
            className="gap-2"
          >
            <MessageCircle className="h-4 w-4" />
            Комментарии
          </Button>
          {user?.id === post.user_id && (
            <Button variant="ghost" size="sm" onClick={deletePost} className="ml-auto gap-2 text-destructive">
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>

        {showComments && (
          <div className="space-y-3">
            <div className="space-y-2">
              {comments.map((c) => (
                <div key={c.id} className="flex items-start gap-2 rounded-md bg-muted/50 p-2">
                  <Avatar className="h-7 w-7">
                    <AvatarImage src={c.profiles?.avatar_url ?? undefined} />
                    <AvatarFallback>{c.profiles?.username?.[0]?.toUpperCase() ?? "?"}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-sm">
                    <Link
                      to="/profile/$id"
                      params={{ id: c.user_id }}
                      className="font-medium hover:underline inline-flex items-center gap-1"
                    >
                      {c.profiles?.username ?? "Пользователь"}
                      {c.profiles?.is_verified && <VerifiedBadge />}
                    </Link>
                    <span className="ml-2 text-xs text-muted-foreground">{timeAgo(c.created_at)}</span>
                    <p className="whitespace-pre-wrap">{c.content}</p>
                  </div>
                </div>
              ))}
              {comments.length === 0 && (
                <p className="text-xs text-muted-foreground">Пока нет комментариев</p>
              )}
            </div>

            {user ? (
              <form onSubmit={submitComment} className="flex gap-2">
                <Textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Напишите комментарий…"
                  rows={2}
                  maxLength={1000}
                />
                <Button type="submit" disabled={busy}>OK</Button>
              </form>
            ) : (
              <p className="text-xs text-muted-foreground">
                <Link to="/auth" className="underline">Войдите</Link>, чтобы комментировать
              </p>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
