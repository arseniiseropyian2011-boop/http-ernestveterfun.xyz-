import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { MessageCircle, UserPlus, UserCheck, UserX } from "lucide-react";
import { toast } from "sonner";

type Status = "none" | "pending_out" | "pending_in" | "friends" | "self";

export function FriendButton({ targetId }: { targetId: string }) {
  const { user } = useAuth();
  const [status, setStatus] = useState<Status>("none");
  const [busy, setBusy] = useState(false);

  const load = async () => {
    if (!user) return setStatus("none");
    if (user.id === targetId) return setStatus("self");
    const { data } = await supabase
      .from("friendships")
      .select("requester_id, addressee_id, status")
      .or(
        `and(requester_id.eq.${user.id},addressee_id.eq.${targetId}),and(requester_id.eq.${targetId},addressee_id.eq.${user.id})`,
      )
      .maybeSingle();
    if (!data) return setStatus("none");
    if (data.status === "accepted") return setStatus("friends");
    setStatus(data.requester_id === user.id ? "pending_out" : "pending_in");
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [user?.id, targetId]);

  if (!user || status === "self") return null;

  const send = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("friendships")
      .insert({ requester_id: user.id, addressee_id: targetId });
    setBusy(false);
    if (error) return toast.error(error.message);
    setStatus("pending_out");
  };

  const accept = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("friendships")
      .update({ status: "accepted" })
      .eq("requester_id", targetId)
      .eq("addressee_id", user.id);
    setBusy(false);
    if (error) return toast.error(error.message);
    setStatus("friends");
  };

  const remove = async () => {
    setBusy(true);
    const { error } = await supabase
      .from("friendships")
      .delete()
      .or(
        `and(requester_id.eq.${user.id},addressee_id.eq.${targetId}),and(requester_id.eq.${targetId},addressee_id.eq.${user.id})`,
      );
    setBusy(false);
    if (error) return toast.error(error.message);
    setStatus("none");
  };

  return (
    <div className="flex gap-2">
      {status === "none" && (
        <Button size="sm" onClick={send} disabled={busy} className="gap-2">
          <UserPlus className="h-4 w-4" /> В друзья
        </Button>
      )}
      {status === "pending_out" && (
        <Button size="sm" variant="outline" onClick={remove} disabled={busy}>Отменить запрос</Button>
      )}
      {status === "pending_in" && (
        <>
          <Button size="sm" onClick={accept} disabled={busy} className="gap-2">
            <UserCheck className="h-4 w-4" /> Принять
          </Button>
          <Button size="sm" variant="outline" onClick={remove} disabled={busy} className="gap-2">
            <UserX className="h-4 w-4" /> Отклонить
          </Button>
        </>
      )}
      {status === "friends" && (
        <Button size="sm" variant="secondary" onClick={remove} disabled={busy} className="gap-2">
          <UserCheck className="h-4 w-4" /> В друзьях
        </Button>
      )}
      <Link to="/messages/$id" params={{ id: targetId }}>
        <Button size="sm" variant="outline" className="gap-2">
          <MessageCircle className="h-4 w-4" /> Написать
        </Button>
      </Link>
    </div>
  );
}
