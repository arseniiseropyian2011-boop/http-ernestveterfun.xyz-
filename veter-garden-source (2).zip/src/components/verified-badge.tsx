import { BadgeCheck } from "lucide-react";

export function VerifiedBadge({ className = "" }: { className?: string }) {
  return (
    <BadgeCheck
      className={`inline h-4 w-4 fill-primary text-primary-foreground ${className}`}
      aria-label="Подтверждённый аккаунт"
    />
  );
}
