import { useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { detectMediaType, uploadMedia } from "@/lib/media";
import { VoiceRecorder } from "@/components/voice-recorder";
import { MediaPreview } from "@/components/media-preview";
import { ImagePlus, X } from "lucide-react";

export function CreatePost() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [content, setContent] = useState("");
  const [busy, setBusy] = useState(false);
  const [file, setFile] = useState<File | Blob | null>(null);
  const [fileExt, setFileExt] = useState<string>("");
  const [mediaType, setMediaType] = useState<"image" | "video" | "audio" | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  if (!user) {
    return (
      <Card>
        <CardContent className="p-4 text-center text-sm text-muted-foreground">
          <Link to="/auth" className="font-medium text-primary underline">Войдите</Link>{" "}
          чтобы публиковать посты
        </CardContent>
      </Card>
    );
  }

  const setMedia = (f: File | Blob, ext: string, type: "image" | "video" | "audio") => {
    setFile(f);
    setFileExt(ext);
    setMediaType(type);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(URL.createObjectURL(f));
  };

  const clearMedia = () => {
    setFile(null); setMediaType(null); setFileExt("");
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    if (f.size > 25 * 1024 * 1024) return toast.error("Файл больше 25 МБ");
    const t = detectMediaType(f);
    if (!t) return toast.error("Неподдерживаемый формат");
    setMedia(f, f.name.split(".").pop() || "bin", t);
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = content.trim();
    if (!text && !file) return;
    setBusy(true);
    try {
      let media_url: string | null = null;
      let media_type: "image" | "video" | "audio" | null = null;
      if (file && mediaType) {
        const { url } = await uploadMedia("post-media", user.id, file, fileExt || "webm");
        media_url = url;
        media_type = mediaType;
      }
      const { error } = await supabase.from("posts").insert({
        user_id: user.id,
        content: text || null,
        media_url,
        media_type,
      });
      if (error) throw error;
      setContent("");
      clearMedia();
      qc.invalidateQueries({ queryKey: ["posts"] });
      toast.success("Опубликовано");
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardContent className="p-4">
        <form onSubmit={submit} className="space-y-3">
          <Textarea
            placeholder="Что нового?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={3}
            maxLength={2000}
          />

          {previewUrl && mediaType && (
            <div className="relative">
              <MediaPreview url={previewUrl} type={mediaType} />
              <Button
                type="button"
                size="icon"
                variant="secondary"
                onClick={clearMedia}
                className="absolute right-2 top-2"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}

          <div className="flex flex-wrap items-center gap-2">
            <input
              ref={fileRef}
              type="file"
              accept="image/*,video/*,audio/*"
              onChange={onFile}
              className="hidden"
            />
            <Button type="button" size="sm" variant="outline" onClick={() => fileRef.current?.click()} className="gap-2">
              <ImagePlus className="h-4 w-4" />
              Файл
            </Button>
            <VoiceRecorder
              onRecorded={(blob) => setMedia(blob, "webm", "audio")}
              disabled={!!file}
            />
            <Button type="submit" disabled={busy || (!content.trim() && !file)} className="ml-auto">
              {busy ? "Загрузка…" : "Опубликовать"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
