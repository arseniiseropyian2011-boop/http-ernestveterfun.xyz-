import type { MediaType } from "@/lib/media";

export function MediaPreview({ url, type }: { url: string; type: MediaType }) {
  if (type === "image") {
    return <img src={url} alt="" className="max-h-96 w-full rounded-md object-cover" />;
  }
  if (type === "video") {
    return <video src={url} controls className="max-h-96 w-full rounded-md" />;
  }
  return <audio src={url} controls className="w-full" />;
}
