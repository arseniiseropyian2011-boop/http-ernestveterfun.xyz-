import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Mic, Square, Trash2 } from "lucide-react";

type Props = {
  onRecorded: (blob: Blob) => void;
  disabled?: boolean;
};

export function VoiceRecorder({ onRecorded, disabled }: Props) {
  const [recording, setRecording] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const blobRef = useRef<Blob | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => () => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    if (timerRef.current) clearInterval(timerRef.current);
  }, [previewUrl]);

  const start = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => e.data.size && chunksRef.current.push(e.data);
      rec.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        blobRef.current = blob;
        if (previewUrl) URL.revokeObjectURL(previewUrl);
        setPreviewUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach((t) => t.stop());
      };
      rec.start();
      recRef.current = rec;
      setRecording(true);
      setSeconds(0);
      timerRef.current = setInterval(() => setSeconds((s) => s + 1), 1000);
    } catch (e) {
      console.error(e);
      alert("Нет доступа к микрофону");
    }
  };

  const stop = () => {
    recRef.current?.stop();
    setRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const send = () => {
    if (blobRef.current) {
      onRecorded(blobRef.current);
      blobRef.current = null;
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
      setSeconds(0);
    }
  };

  const clear = () => {
    blobRef.current = null;
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setSeconds(0);
  };

  if (previewUrl) {
    return (
      <div className="flex items-center gap-2 rounded-md border border-border bg-muted p-2">
        <audio src={previewUrl} controls className="h-8 flex-1" />
        <Button type="button" size="sm" onClick={send} disabled={disabled}>Отправить</Button>
        <Button type="button" size="icon" variant="ghost" onClick={clear}><Trash2 className="h-4 w-4" /></Button>
      </div>
    );
  }

  return (
    <Button
      type="button"
      size="sm"
      variant={recording ? "destructive" : "outline"}
      onClick={recording ? stop : start}
      disabled={disabled}
      className="gap-2"
    >
      {recording ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
      {recording ? `Стоп ${seconds}s` : "Голосовое"}
    </Button>
  );
}
