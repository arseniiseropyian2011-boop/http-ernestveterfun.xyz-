import { supabase } from "@/integrations/supabase/client";

export type MediaType = "image" | "video" | "audio";

export function detectMediaType(file: File): MediaType | null {
  if (file.type.startsWith("image/")) return "image";
  if (file.type.startsWith("video/")) return "video";
  if (file.type.startsWith("audio/")) return "audio";
  return null;
}

export async function uploadMedia(
  bucket: "post-media" | "dm-media" | "avatars",
  userId: string,
  file: File | Blob,
  ext: string,
): Promise<{ url: string; path: string }> {
  const path = `${userId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    upsert: false,
    contentType: (file as File).type || undefined,
  });
  if (error) throw error;
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return { url: data.publicUrl, path };
}
